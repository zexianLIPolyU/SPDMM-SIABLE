% test state_preparation
clc ; clear ; close all ; 
addpath('QCLAB') ; 
addpath("spdmm_siable") ; 

logging = true; % no record 
circuit_sim = true ; 

n = 3;
N = pow2(n) ; 
state_complex = randn(N,1) + randn(N,1) .* 1j ; 
% state_complex = [exp(2*pi/4*1j); exp(3*pi/4*1j); exp(5*pi/4*1j); exp(7*pi/4*1j); exp(11*pi/4*1j); exp(13*pi/4*1j); exp(17*pi/4*1j); exp(19*pi/4*1j)];
state_complex = state_complex ./ norm(state_complex,2) ; 
[circuit, global_phase, CNOT_count] = state_preparation( state_complex, 1, logging ) ; 
fprintf("N_state(%d) = %d\n\n ", n, CNOT_count) ; 
circuit.draw() 
M = circuit.matrix ; 
norm(M(:,1) .* global_phase - state_complex )